package Catalyst::Action::Deserialize::View;

use strict;
use warnings;

use base 'Catalyst::Action';

sub execute {
    return 1;
}

1;