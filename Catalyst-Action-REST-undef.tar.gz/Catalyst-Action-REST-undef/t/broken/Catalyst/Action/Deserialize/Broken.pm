package Catalyst::Action::Serializer::Broken;

use strict;
use warnings;

use Bilbo::Baggins;

1;

